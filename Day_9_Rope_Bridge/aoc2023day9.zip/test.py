test = [[1, 0], [2, 0], [3, 0], [4, 1], [4, 2], [4, 3], [3, 4], [2, 4], [3, 3], [4, 3], [3, 2], [2, 2], [1, 2], (1, 0)] 
print(len(test))
print([4, 3] in test)
print(test.count([4, 3]))

print('=' * 50)
start = (0, 0)
asd = [start]
asd.append([0,0])

print(asd)
